# Manage Kodi Favourites Program Addon - To Do
![icon](https://github.com/M-Borsch/Manage-Kodi-Favourites/blob/main/Manage-Kodi-Fav-icon.png)  

### This is a simple & lightweight program add-on that lets you quickly manage your Kodi favourites by adding Prefixes, Suffixes and use Colors to better oraganize your Favourites list that works on multiple Kodi skins.
> [!NOTE]
> - [ ] - (Contextual Popup) - Add ability to display a text version of your Favourites
> 
> - [ ] - (Configuration Panel) - Add ability to edit lists and colors
>
> - [ ] - (Write Out New file) - Add ability to manipuate the Favourites list
>

